function love.conf(c)
  c.title = "Block Breaker Extreme VS Mode"
  local window = c.screen or c.window -- love 0.9 renamed "screen" to "window"
  window.width = 360
  window.height = 640
end